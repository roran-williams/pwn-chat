# `@tailwindcss/oxide-linux-arm64-gnu`

This is the **aarch64-unknown-linux-gnu** binary for `@tailwindcss/oxide`
